#ifndef VERSION_H
#define VERSION_H

#define VERSION_STR "0.6.3"

#endif /* VERSION_H */
